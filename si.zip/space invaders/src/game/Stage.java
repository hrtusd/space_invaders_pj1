package game;

public enum Stage {
  START, GAME, END, WIN;
}
