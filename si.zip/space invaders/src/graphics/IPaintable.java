package graphics;

import java.awt.Graphics;

public interface IPaintable {

  public void paint(Graphics g);

}
